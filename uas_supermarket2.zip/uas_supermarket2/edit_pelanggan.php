<?php
require_once('koneksi.php');


// berikut script untuk proses edit barang ke database 
if (!empty($_POST['nama_palanggan'])) {


    // menangkap data post 
    $nama_pelanggan = $_POST['nama_pelanggan'];
    $no_tlp = $_POST['no_tlp'];
    $status_pelanggan = $_POST['status_pelanggan'];

    $data[] = $nama_pelanggan;
    $data[] = $no_tlp;
    $data[] = $status_pelanggan;


    // simpan data barang

    $sql = 'UPDATE pelanggan SET nama_pelanggan=?, no_tlp=?, status_pelanggan=? WHERE id_pelanggan=?';
    $row = $koneksi->prepare($sql);
    $row->execute($data);

    // redirect
    echo '<script>alert("Berhasil Edit Data");window.location="lihat_pelanggan.php"</script>';
}
// untuk menampilkan data barang berdasarkan id barang
$id = $_GET['id'];
$sql = "SELECT *FROM pelanggan WHERE id_pelanggan= ?";
$row = $koneksi->prepare($sql);
$row->execute(array($id));
$hasil = $row->fetch();

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>RESTORAN</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
                <div class="sidebar-brand-icon rotate-n-15">
                </div>
                <div class="sidebar-brand-text mx-3">RESTORAN</div>
            </a>


            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>




            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Master Pelanggan</span>
                </a>


                <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Master Pelanggan:</h6>
                        <a class="collapse-item" href="input_pelanggan.php">Input Pelangan</a>
                        <a class="collapse-item" href="lihat_pelanggan.php">Lihat Pelanggan</a>
                    </div>
                </div>
            </li>



            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Master Barang</span>
                </a>


                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Master Barang:</h6>
                        <a class="collapse-item" href="input_barang.php">Input Barang</a>
                        <a class="collapse-item" href="lihat_barang.php">Lihat Barang</a>
                    </div>
                </div>
            </li>



            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Master Kategori</span>
                </a>


                <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Master Kategori:</h6>
                        <a class="collapse-item" href="input_kategori.php">Input Kategori</a>
                        <a class="collapse-item" href="lihat_kategori.php">Lihat Kategori</a>
                    </div>
                </div>
            </li>


            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Master Satuan</span>
                </a>


                <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Master Satuan:</h6>
                        <a class="collapse-item" href="input_satuan.php">Input Satuan</a>
                        <a class="collapse-item" href="lihat_satuan.php">Lihat Satuan</a>
                    </div>
                </div>
            </li>


            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFive" aria-expanded="true" aria-controls="collapseFive">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Master Transaksi</span>
                </a>


                <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Master Transaksi:</h6>
                        <a class="collapse-item" href="input_transaksi.php">Input Transaksi</a>
                        <a class="collapse-item" href="lihat_transaksi.php">Lihat Transaksi</a>
                    </div>
                </div>
            </li>



            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>



        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                </nav>
                <!-- End of Topbar -->



                <div class="container">
                    <br />
                    <h3>Edit Pelanggan - <?php echo $hasil['nama_pelanggan']; ?></h3>
                    <br />
                    <div class="row">
                        <div class="col-lg-6">
                            <form action="" method="POST">
                                <div class="form-group">
                                    <label>ID pelanggan</label>
                                    <input type="text" value="<?php echo $hasil['id_pelanggan']; ?>" class="form-control" name="id_pelanggan">
                                </div>
                                <div class="form-group">
                                    <label>Nama</label>
                                    <input type="text" value="<?php echo $hasil['nama_pelanggan']; ?>" class="form-control" name="nama_pelanggan">
                                </div>
                                <div class="form-group">
                                    <label>No Tlp</label>
                                    <input type="text" value="<?php echo $hasil['no_tlp']; ?>" class="form-control" name="no_tlp">
                                </div>
                                <div class="form-group">
                                    <label>Status</label>
                                    <input type="text" value="<?php echo $hasil['status_pelanggan']; ?>" class="form-control" name="status_pelanggan">
                                </div>
                                <input type="hidden" value="<?php echo $hasil['id_pelanggan']; ?>" name="id_pelanggan">
                                <button class="btn btn-primary btn-md" name="create"><i class="fa fa-edit"> </i> Update</button>
                            </form>
                        </div>
                    </div>
                </div>



            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->



    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>