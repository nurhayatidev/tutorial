<?php
require_once('koneksi.php');

$id_pelanggan = $_GET['id_pelanggan'];
$sql = "DELETE FROM pelanggan WHERE id_pelanggan= ?";
$row = $koneksi->prepare($sql);
$row->execute(array($id_pelanggan));

echo '<script>alert("Berhasil Hapus Data");window.location="lihat_pelanggan.php"</script>';
